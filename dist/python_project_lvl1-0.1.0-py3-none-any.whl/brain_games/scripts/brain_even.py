#!/usr/bin/env python
from brain_games.games.newgames import new_game


def main():
    new_game()


if __name__ == '__main__':
    main()
